/*package com.abc.service.controller;


import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;





@Configuration
public class AppConfig {
	@Autowired
	KIEHelper kiehelper;
	
    @Bean(name="ksession")
    public KieSession getkieSession() {
        return kiehelper.getKieSession();
    }

}*/