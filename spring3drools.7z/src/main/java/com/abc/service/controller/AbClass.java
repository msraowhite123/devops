package com.abc.service.controller;

abstract public class AbClass {

	public static void methodS() {
		System.out.println("static in ab class");
	}

	abstract protected void methos();
}
