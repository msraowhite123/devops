package com.abc.service.controller;

public interface Abinterface {
	
	public  void methodss();

}
