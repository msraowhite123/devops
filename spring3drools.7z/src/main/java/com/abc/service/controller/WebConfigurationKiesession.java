/*package com.abc.service.controller;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public interface WebConfigurationKiesession {
	KieContainer createKieContainerForProject();
	KieSession loadDroolsConfiguration();
}
*/